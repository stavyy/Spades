/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spades;

import constants.Constants;   //imports
import core.AiPlayer;
import core.Game;
import core.HumanPlayer;
import javax.swing.JOptionPane;

/**
 *
 * @author Stavros
 */
public class Spades {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
                
        System.out.println("Welcome to spades!");

        
        
        JOptionPane.showMessageDialog(null, "Let's Play Spades!");
        
        Game game = new Game();                 // Game constructor
        for (int i = 0; i < Constants.NUM_AI_PLAYERS; i++)
        {
            AiPlayer aip = new AiPlayer ();
        }
        
                
        
               HumanPlayer hp = new HumanPlayer();     // New HP constuctor
    }

}
